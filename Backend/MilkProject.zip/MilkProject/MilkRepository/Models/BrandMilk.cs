﻿using System;
using System.Collections.Generic;

namespace MilkRepository.Models;

public partial class BrandMilk
{
    public int BrandMilkId { get; set; }

    public string BrandName { get; set; } = null!;

    public int? CompanyId { get; set; }

    public virtual Company? Company { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
